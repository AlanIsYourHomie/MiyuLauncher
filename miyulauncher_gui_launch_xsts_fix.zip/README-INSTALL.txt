MIYULAUNCHER — INTEGRACIÓN DEL BOTÓN JUGAR (CORRECCIÓN XUID/XSTS)

Contenido del parche
- src/miyu_launcher/core/game_launcher.py
  Integra la preparación de Minecraft, la resolución/instalación de Java, los recursos,
  las bibliotecas nativas, el inicio de sesión Microsoft y la ejecución del juego.
  Corrige la obtención del XUID solicitándolo a XSTS con RelyingParty http://xboxlive.com.
- src/miyu_launcher/ui/main_window.py
  Añade el selector de versión, estado/progreso de lanzamiento, código de dispositivo
  Microsoft y detección de cuándo Minecraft se cierra.

Cómo instalarlo en Windows
1. Cierra MiyuLauncher si lo tienes abierto.
2. Extrae la carpeta del ZIP dentro de:
   C:\Users\User\Documents\PROYECTOS PROPIOS\MiyuLauncher
   Acepta combinar carpetas y reemplazar src\miyu_launcher\ui\main_window.py.
3. Comprueba que el nuevo archivo existe aquí:
   src\miyu_launcher\core\game_launcher.py
4. Abre CMD en la carpeta del proyecto y ejecuta:
   python -m compileall src\miyu_launcher
   python main.py
5. Selecciona una versión instalada (por ejemplo, 26.3) y pulsa JUGAR.
6. En el primer inicio, se abrirá Microsoft en el navegador. Inicia sesión con la cuenta
   que tiene Minecraft: Java Edition e introduce el código que muestra MiyuLauncher.

Notas
- El ID de cliente Microsoft de la aplicación es público y viene configurado por defecto;
  MIYU_MS_CLIENT_ID sigue disponible como variable de entorno para sobrescribirlo durante
  desarrollo. No hace falta configurar esa variable para ejecutar la interfaz normalmente.
- Este hito sigue utilizando la instalación estándar %APPDATA%\\.minecraft, igual que la
  prueba ya validada. La instancia independiente se desarrollará después.
- La corrección evita la consulta de XUID al endpoint XBL equivocado; la obtiene con XSTS.
- La sesión Microsoft todavía se solicita en cada lanzamiento. El almacenamiento seguro
  y la renovación de sesión persistente serán una fase posterior.
- No se muestran ni se guardan deliberadamente tokens en la interfaz o en archivos de log.
- Si el juego falla tras iniciarse, revisa %APPDATA%\\.minecraft\\logs\\latest.log.
